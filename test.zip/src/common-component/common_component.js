import React from 'react';
import _ from 'lodash';
//import {Field} from 'redux-form';

export function renderField(field){
    const {meta: {touched, error}} = field;
    return(
        <div>
            <label>{field.label}</label>
            <input type={field.type} {...field.input} />

            {touched ? error : ''}

        </div>
    );
}


export function renderGender(field){
    const {meta: {touched, error}} = field;
    return(
        <div>{touched ? error : ''}</div>
    );
}


export function renderDropDown(field) {
    const allvalues = field.allvalues;
    const {meta: {touched, error}} = field;

    return(
        <div> {field.label}
            <select {...field.input}>
                <option value="">Select {field.label}</option>
                {
                    _.map(allvalues, (val,key) => {
                        return (
                            <option value={key} key={key}>{val}</option>
                        )
                    })
                }
            </select>
            {touched ? error : ''}
        </div>
    );
}


/*export function renderMembers({ fields, meta: { error, submitFailed } }) {
    return(
        <div>
    <ul>
        <li>
            <button type="button" onClick={() => fields.push({})}>
                Add Member
            </button>
            {submitFailed && error && <span>{error}</span>}
        </li>
        {fields.map((member, index) => (
            <li key={index}>

                <button
                    type="button"
                    title="Remove Member"
                    onClick={() => fields.remove(index)}
                >
                    Remove Member
                </button>
                <h4>Member #{index + 1}</h4>
                <Field
                    name={`${member}.firstName`}
                    type="text"
                    component={renderField}
                    label="First Name"

                />
                <Field
                    name={`${member}.lastName`}
                    type="text"
                    component={renderField}
                    label="Last Name"
                />

            </li>
        ))}
    </ul>
        </div>
    )
}*/
