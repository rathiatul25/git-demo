import axios from 'axios';
import {CheckAuth} from '../components/auth';
export const USER_LIST = 'user_list';
export const USER_ADD = 'user_add';
export const DEFAULT_ERROR = 'default_error';
export const SUCCESS_MSG = 'success_msg';
export const COUNTRY_LIST = 'country_list';
export const STATE_LIST = 'state_list';
export const USER_SHOW = 'user_show';
export const USER_DELETE = 'user_delete';
export const USER_EDIT = 'user_edit';
export const USER_LOGIN = 'user_login';

const APP_URL = 'http://lara56.local.com/api/';
const token = CheckAuth();

export function getUserList(pageNumber, callback) {
    const token = CheckAuth();
    //const request = axios.get(`${APP_URL}user-list`);
    const request = axios.get(`${APP_URL}user-list?token=${token}&page=${pageNumber}`);
    return (dispatch) => {
        request.then( (data) => {
            callback(data);
            dispatch({
                type:USER_LIST,
                payload:data
            })
        }).catch((error) => {
            //localStorage.removeItem('token')
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function userAdd(values, callBack) {
    const request = axios.post(`${APP_URL}save-user?token=${token}`, values);

    return (dispatch) => {
        request.then((data) => {

            callBack(data);

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function userShow(id) {
    const request = axios.get(`${APP_URL}show-user/${id}?token=${token}`);

    return (dispatch) => {
        request.then((data) => {

            dispatch({
                type:USER_SHOW,
                payload:data
            })

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function userEdit(id, callback) {
    //const request = axios.get(`${APP_URL}user-edit/${id}`);
    const request = axios.get(`${APP_URL}user-edit/${id}?token=${token}`);

    return (dispatch) => {
        request.then((data) => {
            callback(data);
            dispatch({
                type:USER_EDIT,
                payload:data
            })

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function userUpdate(values, id, callBack) {
    const request = axios.post(`${APP_URL}update-user/${id}?token=${token}`, values);

    return (dispatch) => {
        request.then((data) => {

            callBack(data);

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function userDelete(id, callback) {
    const request = axios.post(`${APP_URL}delete-user/${id}/delete?token=${token}`);

    return (dispatch) => {
        request.then((data) => {
            callback(data);
            /*dispatch({
                type:USER_DELETE,
                payload:data
            })*/

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function countryList(callback) {
    const request = axios.get(`${APP_URL}country-list`);

    return (dispatch) => {
        request.then((data) => {
            callback(data);
            dispatch({
                type:COUNTRY_LIST,
                payload:data
            })

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function stateByCountryList(country_id, callback) {
    const request = axios.get(`${APP_URL}state-list/${country_id}`);

    return (dispatch) => {
        request.then((data) => {
            callback(data);
            dispatch({
                type:STATE_LIST,
                payload:data
            })

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function userLogin(values, callBack) {
    const request = axios.post(`${APP_URL}login`, values);

    return (dispatch) => {
        request.then(({data}) => {

            localStorage.setItem('token', data.token);

            callBack(data);
            dispatch({
                type:USER_LOGIN,
                payload:true
            })

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

export function userLogout(callback) {
    let token = localStorage.getItem('token');
    const request = axios.post(`${APP_URL}logout?token=${token}`);

    return (dispatch) => {
        request.then(({data}) => {
            localStorage.removeItem('token');
            callback();

        }).catch((error) => {
            dispatch({
                type:DEFAULT_ERROR,
                payload:error.response
            })
        })
    }
}

/*
export function userLogout() {
    return (dispatch) => {
        localStorage.removeItem('token');
    }
}*/
