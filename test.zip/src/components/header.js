import React from 'react';
import {Link} from 'react-router-dom';
import {CheckAuth} from './auth';

export function Header() {
    return(
        <div>
            <Link to='/'>List</Link> | <Link to={'/add-user'}>Add User</Link>
            | {CheckAuth() ? <Link to={'/logout'}>Logout</Link> : <Link to={'/login'}>Login</Link>}
        </div>
    )
}
