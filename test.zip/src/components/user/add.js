import React,{Component} from 'react';
import {Field, reduxForm, FieldArray} from 'redux-form';
import {connect} from 'react-redux';
import {userAdd, userEdit, userUpdate, countryList, stateByCountryList} from '../../actions/index';
import { Button } from 'reactstrap';
import {toastr} from 'react-redux-toastr';
import * as validations from '../../validation/validation';
import * as common_component from '../../common-component/common_component';

import InputBox from '../../common-component/Input';
import {Header} from '../header';
import {CheckAuth} from '../auth';

const renderMembers_bk = ({ fields, meta: { error, submitFailed } }) => (
    <ul>
        <li>
            <button type="button" onClick={() => fields.push({})}>
                Add Member
            </button>
            {submitFailed && error && <span>{error}</span>}
        </li>
        {fields.map((member, index) => (
            <li key={index}>

                <button
                    type="button"
                    title="Remove Member"
                    onClick={() => fields.remove(index)}
                >
                    Remove Member
                </button>
                <h4>Member #{index + 1}</h4>
                <Field
                    name={`${member}.firstName`}
                    type="text"
                    component={common_component.renderField}
                    label="First Name"

                />
                <Field
                    name={`${member}.lastName`}
                    type="text"
                    component={common_component.renderField}
                    label="Last Name"
                />

            </li>
        ))}
    </ul>
)

class AddUser extends Component{
    constructor(props) {
        super(props);
        this.state={
            isSubmitted:false,
            designation:'',

            states:{},
            countries:{},
            selectedFile:null

        }
    }

    componentDidMount(){
        console.log('did-second')

    }
    componentWillMount(){
        console.log('will-first')

        if(Object.keys(CheckAuth()).length == 0) {
            this.props.history.push('/login');
        }
        else {
            this.props.countryList(res => {
                this.setState({
                    countries: res.data
                });
            });

            if (this.props.match.params.id) {
                console.log('did-second')
                const {id} = this.props.match.params;

                this.props.userEdit(id, (res) => {

                    this.setState({designation: res.data.designation});

                    this.props.stateByCountryList(res.data.country_id, res => {

                        this.setState({states: res.data})
                    });

                });

            }
        }

    }

    onInputChange(value) {
        if(value) {
            this.setState({designation: value,isSubmitted:true});
        }
    }


    getState(e){
        let country_id = e.target.value;
        if (country_id){
            this.props.stateByCountryList(country_id, res => {

                this.setState({states:res.data})
            });
        } else {
            this.setState({states:{}});
        }

    }


    onSubmit(values) {
        values.designation = this.state.designation;

        if(values.status === true) {
            values.status = 1;
        }else{
            values.status = 0;
        }

        let formData = new FormData();
        formData.append('image', this.state.selectedFile);


        for (let uploaded_file of formData.values()) {
            values.uploaded_file = uploaded_file;
        }

        if (this.props.match.params.id) {
            const {id} = this.props.match.params;

            this.props.userUpdate(values, id, (response) => {

                if (response.data.status === 0) {
                    toastr.error('Failure', response.data.message);

                } else {
                    toastr.success('Success', response.data.message);
                    this.props.history.push('/');
                }
            })
        } else {
            this.props.userAdd(values, (response) => {

                if (response.data.status === 0) {
                    toastr.error('Failure', response.data.message);

                } else {
                    toastr.success('Success', response.data.message);
                    this.props.history.push('/');
                }
            })
        }
    }
    fileSelectedHandler = (e) => {
        this.setState({
            selectedFile:e.target.files[0]
        })

    }

    render(){
        const {handleSubmit} = this.props;

        return(
            <div>
                <Header />
                <form onSubmit={handleSubmit(this.onSubmit.bind(this))}>

                    <div>
                        <input type="file" onChange={this.fileSelectedHandler}/>
                    </div>


                    <div>
                    <Field name="name" type="text" label="Name"
                            component={common_component.renderField}
                            validate={[validations.required]}
                    />
                    </div>
                    <div>
                        <Field name="email" type="text" label="Email"
                               component={common_component.renderField}
                               validate={[validations.required, validations.email]}
                        />
                    </div>
                    {! (this.props.match.params.id)  &&
                        <div>
                        <Field name="password" type="password" label="Password"
                        component={common_component.renderField}
                        validate={[validations.required, validations.minLength4, validations.maxLength15]}
                        />
                        </div>
                    }

                    <div>
                        Male <Field label="Male" type="radio" value="Male" name="gender"
                                    component="input"
                        />
                        Female <Field label="Female" type="radio" value="Female" name="gender"
                                    component="input"
                        />
                        <Field name="gender" component={common_component.renderGender} validate={[validations.required]} />
                    </div>
                    <div>
                        <InputBox name='designation' label='Designation'
                                onChange={(e) => {this.onInputChange(e.target.value)}}
                                value={this.state.designation}
                                isSubmitted={this.state.isSubmitted}
                        />
                    </div>
                    <div>
                        Status <Field
                            name="status"
                            id="status"
                            component="input"
                            type="checkbox"
                        />
                    </div>
                    <div>
                        <Field name="country_id" label="Country"
                               allvalues={this.state.countries}
                               component={common_component.renderDropDown}
                               validate={[validations.required]}
                               onChange={(e) => this.getState(e)}
                        />
                    </div>
                    <div>

                        <Field name="state_id" label="State"
                               allvalues={this.state.states}
                               component={common_component.renderDropDown}
                               validate={[validations.required]}
                        />
                    </div>
                    {/*<div>
                        <FieldArray name="members" component={common_component.renderMembers}  />
                    </div>*/}


                    <Button type="submit" onClick={() => {this.setState({isSubmitted:true})}}>Submit</Button>
                </form>
            </div>
        )
    }
}
function mapStateToProps(state, ownProps) {
    let return_val = {};
    if(typeof ownProps.match.params.id !=='undefined') {

        return_val.initialValues = state.users.user_edit;
    }
    return return_val;
}


AddUser = (reduxForm({

    form: 'initializeFromState',
    enableReinitialize:true
})(AddUser))
AddUser = connect(
    mapStateToProps,{userAdd, userEdit, userUpdate, countryList, stateByCountryList}
)(AddUser)
export default AddUser;



