import React, {Component} from 'react';
import {connect} from 'react-redux';
import {userShow} from '../../actions/index';
import { Table } from 'reactstrap';
import {Header} from '../header';
import {CheckAuth} from '../auth';
//import {Link,Redirect} from 'react-router-dom';

class ShowUser extends Component{

    componentDidMount() {
        const {id} = this.props.match.params;
        this.props.userShow(id);

        if(Object.keys(CheckAuth()).length == 0) {
            this.props.history.push('/login');
        }
    }
    render() {
        const {user} = this.props;

        if(!user){
            return <div>Loading user</div>
        }

        return (
            <div>
                <Header />
                <Table>
                    <tbody>

                    <tr>
                        <td>ID</td>
                        <td>{user.id}</td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>{user.name}</td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td>{user.gender}</td>
                    </tr>
                    <tr>
                        <td>Designation</td>
                        <td>{user.designation}</td>
                    </tr>
                    <tr>
                        <td>Country</td>
                        <td>{user.country_name}</td>
                    </tr>
                    <tr>
                        <td>State</td>
                        <td>{user.state_name}</td>
                    </tr>
                    </tbody>
                </Table>
            </div>
        )
    }
}

function mapStateToProps(state) {
    //console.log(state.users.user_show);
    return {
        user:state.users.user_show
    }
}
export default connect(mapStateToProps,{userShow})(ShowUser);
