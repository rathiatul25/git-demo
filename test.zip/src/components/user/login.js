import React,{Component} from 'react';
import {Field, reduxForm} from 'redux-form';
import {connect} from 'react-redux';
import {userLogin} from '../../actions/index';
import { Button } from 'reactstrap';
import {toastr} from 'react-redux-toastr';
import * as validations from '../../validation/validation';
import * as common_component from '../../common-component/common_component';
import {Header} from '../header';
import {CheckAuth} from '../auth';

class Login extends Component{

    componentWillMount(){
        console.log('will-first')

        if(Object.keys(CheckAuth()).length>0){
            this.props.history.push('/');
        }

    }

    onSubmit(values) {

        this.props.userLogin(values, (response) => {

            if (response.status === 0) {
                toastr.error('Failure', response.data.message);

            } else {

                toastr.success('Success', 'Logged in');
                this.props.history.push('/');
            }
        })
    }

    render(){
        const {handleSubmit} = this.props;
        return(
            <div>
                <Header />
                <form onSubmit={handleSubmit(this.onSubmit.bind(this))}>
                    <div>
                        <Field name="email" type="text" label="Email"
                               component={common_component.renderField}
                               validate={[validations.required, validations.email]}
                        />
                    </div>
                    <div>
                        <Field name="password" type="password" label="Password"
                               component={common_component.renderField}
                               validate={[validations.required, validations.minLength4, validations.maxLength15]}
                        />
                    </div>

                    <Button type="submit" onClick={() => {this.setState({isSubmitted:true})}}>Submit</Button>
                </form>
            </div>
        )
    }
}
function mapStateToProps() {
    return {}
}

Login = (reduxForm({
    form: 'initializeFromState'
})(Login))
Login = connect(
    mapStateToProps,{userLogin}
)(Login)
export default Login;


