import React,{Component} from 'react';
import {connect} from 'react-redux';
import {userLogout} from '../../actions/index';

class Logout extends Component{

    componentWillMount(){
        console.log('will-first')
        this.props.userLogout(res => {
            this.props.history.push('/login');
        });
        //localStorage.removeItem('token');
        //this.props.history.push('/login');
    }

    render(){
        return(
            <div></div>
        )
    }
}

function mapStateToProps() {
    return {}
}

export default connect(mapStateToProps,{userLogout})(Logout);



