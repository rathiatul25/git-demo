import React, {Component} from 'react';
import {getUserList, userDelete} from '../../actions/index';
import {toastr} from 'react-redux-toastr';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import _ from 'lodash';
import { Table } from 'reactstrap';
import {Link} from 'react-router-dom';
import {Header} from '../header';
import {CheckAuth} from '../auth';
import {Button} from 'react-bootstrap';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css' // Import css
import Pagination from "react-js-pagination";

class UserList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activePage: 1,
            itemsCountPerPage: 1,
            totalItemsCount: 1
        };
        this.handlePageChange = this.handlePageChange.bind(this);
    }
    handlePageChange(pageNumber) {
        this.props.getUserList(pageNumber, (res) => {
            this.setState({
                activePage:res.data.current_page,
                totalItemsCount:res.data.total,
                itemsCountPerPage:res.data.per_page
            })
console.log(res.data)
        })
        this.setState({activePage: pageNumber});
    }
    componentDidMount() {

        if(Object.keys(CheckAuth()).length == 0) {
            this.props.history.push('/login');
        }
        else {
            this.props.getUserList(1, (res) => {
                this.setState({
                    activePage:res.data.current_page,
                    totalItemsCount:res.data.total,
                    itemsCountPerPage:res.data.per_page
                })
            });
        }
    }

    onDeleteClick(id) {

        const toastrMessageOptions = {
            timeOut: 3000,
            onShowComplete:()=>window.location.assign('/')
        }
        confirmAlert({
            title: 'Confirm to submit',
            message: 'Are you sure to do this.',
            buttons: [
                {
                    label: 'Yes',
                    onClick: () => {
                        this.props.userDelete(id, () => {
                            toastr.success('Title', 'Record deleted', toastrMessageOptions)
                        });
                    }
                },
                {
                    label: 'No',
                    onClick: () => {}
                }
            ]
        })
        
    }

    renderPost() {

        return _.map(this.props.all_users, (user) => {

            return (
                <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.name}</td>
                    <td>{user.gender}</td>
                    <td>{user.designation}</td>
                    <td>{user.country_name}</td>
                    <td>{user.state_name}</td>
                    <td>{user.status===1 ? 'Active' : 'Inactive'}</td>
                    <td>
                        <Link to={`/user/${user.id}`}>View</Link> |
                        <Link to={`/user/${user.id}/edit`}> Edit </Link>

                        <Button onClick={this.onDeleteClick.bind(this, user.id)}>Delete</Button>
                    </td>
                </tr>
            )

        })

    }


    render() {
        if(!this.props.all_users) {
            return <div>Loading users...</div>
        }


        return (
            <div>
                <Header />
                <div>

                </div>
                <Table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>Designation</th>
                            <th>Country</th>
                            <th>State</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.renderPost()}
                    </tbody>
                </Table>
                <Pagination
                    activePage={this.state.activePage}
                    itemsCountPerPage={2}
                    totalItemsCount={4}
                    pageRangeDisplayed={5}
                    onChange={this.handlePageChange}
                />
            </div>
        );
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({getUserList: getUserList, userDelete: userDelete}, dispatch);
}

function mapStateToProps(state) {

    return {

        all_users: state.users.users

    }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserList);

//https://daveceddia.com/avoid-bind-when-passing-props/