import {USER_LIST, USER_SHOW, USER_EDIT, USER_LOGIN} from "../actions/index";

export default function (state={}, action) {

    switch (action.type) {
        case USER_LIST :

            return {...state, users:action.payload.data.data};

        case USER_SHOW :

            return {...state, user_show:action.payload.data};

        case USER_EDIT :

            return {...state, user_edit:action.payload.data};

        case USER_LOGIN :
            return {...state, is_loggedin:action.payload.data}

        /*case COUNTRY_LIST :
             return {...state, countries:action.payload.data};

        case STATE_LIST :
            return {...state, states:action.payload.data};*/

        default:
            return state
    }
}