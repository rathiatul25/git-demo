import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
//import promise from 'redux-promise';
import ReduxThunk from 'redux-thunk';
import {BrowserRouter as Router , Route, Switch} from 'react-router-dom';
import reducers from './reducers';

import UserList from './components/user/index';
import AddUser from './components/user/add';
import Login from './components/user/login';
import Logout from './components/user/logout';

import ShowUser from './components/user/show';

import 'bootstrap/dist/css/bootstrap.min.css';
import ReduxToastr from 'react-redux-toastr'
import 'react-redux-toastr/lib/css/react-redux-toastr.min.css'

const createStoreWithMiddleware = applyMiddleware(ReduxThunk)(createStore);


ReactDOM.render(<Provider store={createStoreWithMiddleware(reducers)}>
    <Router>
        <div>
            <Switch>
                <Route path="/login" component={Login}></Route>
                <Route path="/add-user" component={AddUser}></Route>
                <Route path="/user/:id/edit" component={AddUser}></Route>

                <Route path="/user/:id" component={ShowUser}></Route>
                <Route path="/logout" component={Logout}></Route>

                <Route path="/" component={UserList}></Route>
            </Switch>
            <ReduxToastr
                timeOut={4000}
                newestOnTop={false}
                preventDuplicates
                position="top-right"
                transitionIn="fadeIn"
                transitionOut="fadeOut"
                progressBar/>
        </div>
    </Router>


</Provider>, document.getElementById('root'));
//registerServiceWorker();
